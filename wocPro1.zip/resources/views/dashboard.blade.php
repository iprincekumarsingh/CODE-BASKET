<x-app-layout>
 
 <style></style>
</x-app-layout>
