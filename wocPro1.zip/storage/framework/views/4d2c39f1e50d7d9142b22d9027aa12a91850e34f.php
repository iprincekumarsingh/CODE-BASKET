<!DOCTYPE html>
<html style="font-size: 16px;">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="keywords" content="Easy to use">
  <meta name="description" content="">
  <meta name="page_type" content="np-template-header-footer-from-plugin">
  <title>Home</title>
  <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>" media="screen">
  <link rel="stylesheet" href="<?php echo e(url('css/theme.css')); ?>" media="screen">

  <meta name="generator" content="Nicepage 4.4.3, nicepage.com">
  <link id="u-theme-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">



  <meta name="theme-color" content="#478ac9">
  <meta property="og:title" content="Home">
  <meta property="og:type" content="website">
</head>

<body data-home-page="Home.html" data-home-page-title="Home" class="u-body u-xl-mode">
  <section class="u-align-left u-clearfix u-image u-shading u-section-1" src="" data-image-width="256"
    data-image-height="256" id="sec-221e">
    <h1 class="u-text u-text-default u-title u-text-1">WOC</h1>
    <a href="<?php echo e(route('home')); ?>" sy class="u-btn u-button-style u-palette-2-base u-btn-1">Read More</a>
  </section>



</body>

</html><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/welcome.blade.php ENDPATH**/ ?>