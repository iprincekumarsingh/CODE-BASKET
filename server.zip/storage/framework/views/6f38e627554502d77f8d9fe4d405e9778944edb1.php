<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <table class="table">
        <thead>
            <tr>
                <th scope="col">Uploaded By</th>
                <th scope="col">Description</th>
                <th scope="col">Url Source</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $approve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->description); ?></td>
                <td><a href=""><?php echo e($data->link); ?></a></td>
                <td><?php if($data['post_photo1']==null): ?>
                    No Photo
                    <?php else: ?>
                    <img src="<?php echo e(url('upload/oppurtunity/'.$data['post_photo1'])); ?>" width="100px" height="50px" alt="">
                    <?php endif; ?>
                </td>
                <td>
                    <form action="<?php echo e(route('route.approve',['id'=>$data['opid']])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input class="btn btn-success" type="submit" value="Approve">
                    </form>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/admin/approval.blade.php ENDPATH**/ ?>