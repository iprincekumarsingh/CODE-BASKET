<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <style>
        h1 {
            font-size: 5rem;
            text-align: center;
        }
    </style>
</head>

<body>
    <h1><?php echo e($msg); ?>

        <br>
        Hackathon
        <h1 style="color: palevioletred"> Team -KEOS</h1>
    </h1>
</body>

</html><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\WOC_HACKATHAON\wocPro1\resources\views/web/home.blade.php ENDPATH**/ ?>